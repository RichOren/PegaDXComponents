// @ts-nocheck
export const mockTableData = [
  { id: 1, name: "John Doe", email: "john@example.com", role: "Developer" },
  { id: 2, name: "Jane Smith", email: "jane@example.com", role: "Designer" },
  {
    id: 3,
    name: "Alice Johnson",
    email: "alice@example.com",
    role: "Manager",
  },
  { id: 4, name: "Bob Brown", email: "bob@example.com", role: "Developer" },
  {
    id: 5,
    name: "Charlie Davis",
    email: "charlie@example.com",
    role: "Designer",
  },
  { id: 6, name: "Diana Evans", email: "diana@example.com", role: "Tester" },
  { id: 7, name: "Eve Foster", email: "eve@example.com", role: "Support" },
  { id: 8, name: "Frank Green", email: "frank@example.com", role: "Admin" },
  { id: 9, name: "Grace Hall", email: "grace@example.com", role: "HR" },
  {
    id: 10,
    name: "Hank Irwin",
    email: "hank@example.com",
    role: "Developer",
  },
];
